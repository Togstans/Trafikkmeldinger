import { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { 
  Send, 
  Bot, 
  Code, 
  Bug, 
  Rocket, 
  Lightbulb,
  Check,
  Eye,
  MessageSquare,
  Cpu
} from "lucide-react";
import { AIService } from "@/lib/ai-service";
import type { AIMessage, Project } from "@/types/ide";

interface AIChatProps {
  project: Project | null;
  onCodeGenerated: (code: string, fileName: string) => void;
  onCreateFile: (path: string, content: string) => void;
}

export function AIChat({ project, onCodeGenerated, onCreateFile }: AIChatProps) {
  const [messages, setMessages] = useState<AIMessage[]>([
    {
      id: '1',
      type: 'assistant',
      content: "I've created a Feed component with the following features:\n\n• Post display with user info\n• Like and comment functionality\n• Responsive design\n• Loading states",
      timestamp: new Date(Date.now() - 300000).toISOString(),
      actions: [
        { type: 'apply_code', label: 'Applied', data: null },
        { type: 'view_code', label: 'View Code', data: null }
      ]
    }
  ]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'ai' | 'chat' | 'debug'>('ai');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const sendMessage = async () => {
    if (!currentMessage.trim() || isLoading) return;

    const userMessage: AIMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: currentMessage,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setCurrentMessage('');
    setIsLoading(true);

    try {
      const conversationHistory = messages.map(msg => ({
        role: msg.type === 'user' ? 'user' : 'assistant',
        content: msg.content
      }));

      const response = await AIService.sendChatMessage(
        currentMessage,
        project?.id,
        conversationHistory
      );

      const assistantMessage: AIMessage = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: response.response,
        timestamp: response.timestamp,
        actions: currentMessage.toLowerCase().includes('generate') || 
                currentMessage.toLowerCase().includes('create') ||
                currentMessage.toLowerCase().includes('build') ? [
          { type: 'apply_code', label: 'Apply', data: null },
          { type: 'view_code', label: 'View Code', data: null }
        ] : undefined
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Failed to send message:', error);
      const errorMessage: AIMessage = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: 'Sorry, I encountered an error processing your request. Please try again.',
        timestamp: new Date().toISOString()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      sendMessage();
    }
  };

  const generateCode = async (type: 'generate' | 'debug' | 'optimize') => {
    const prompts = {
      generate: 'Create a new React component',
      debug: 'Debug the current code',
      optimize: 'Optimize the current code for better performance'
    };
    
    setCurrentMessage(prompts[type]);
    setTimeout(() => sendMessage(), 100);
  };

  const renderMessage = (message: AIMessage) => {
    const isUser = message.type === 'user';
    
    return (
      <div key={message.id} className={`flex ${isUser ? 'justify-end' : 'justify-start'} ai-message`}>
        {!isUser && (
          <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center mr-2 mt-1 flex-shrink-0">
            <Bot size={16} className="text-white" />
          </div>
        )}
        
        <div className={`max-w-xs rounded-lg p-3 text-sm ${
          isUser 
            ? 'bg-blue-600 text-white' 
            : 'bg-[#2D2D2D] text-gray-200'
        }`}>
          <p className="whitespace-pre-wrap">{message.content}</p>
          
          {message.actions && (
            <div className="mt-3 flex space-x-2">
              {message.actions.map((action, index) => (
                <Button
                  key={index}
                  variant={action.label === 'Applied' ? 'default' : 'outline'}
                  size="sm"
                  className={`text-xs ${
                    action.label === 'Applied' 
                      ? 'bg-green-600 text-white border-green-600' 
                      : 'border-[#3C3C3C] text-gray-300 hover:bg-[#3C3C3C]'
                  }`}
                  disabled={action.label === 'Applied'}
                >
                  {action.label === 'Applied' && <Check size={12} className="mr-1" />}
                  {action.label === 'View Code' && <Eye size={12} className="mr-1" />}
                  {action.label}
                </Button>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="w-80 bg-[#1E1E1E] border-l border-[#3C3C3C] flex flex-col">
      {/* Panel Tabs */}
      <div className="flex border-b border-[#3C3C3C]">
        <Button
          variant="ghost"
          size="sm"
          className={`flex-1 py-2 px-3 text-sm rounded-none ${
            activeTab === 'ai' 
              ? 'bg-[#171717] text-white border-r border-[#3C3C3C]' 
              : 'text-gray-400 hover:text-white hover:bg-[#2D2D2D]'
          }`}
          onClick={() => setActiveTab('ai')}
        >
          <Bot size={14} className="mr-1" />
          AI Assistant
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className={`flex-1 py-2 px-3 text-sm rounded-none ${
            activeTab === 'chat' 
              ? 'bg-[#171717] text-white border-r border-[#3C3C3C]' 
              : 'text-gray-400 hover:text-white hover:bg-[#2D2D2D]'
          }`}
          onClick={() => setActiveTab('chat')}
        >
          <MessageSquare size={14} className="mr-1" />
          Chat
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className={`flex-1 py-2 px-3 text-sm rounded-none ${
            activeTab === 'debug' 
              ? 'bg-[#171717] text-white' 
              : 'text-gray-400 hover:text-white hover:bg-[#2D2D2D]'
          }`}
          onClick={() => setActiveTab('debug')}
        >
          <Bug size={14} className="mr-1" />
          Debug
        </Button>
      </div>

      {/* Chat Interface */}
      <div className="flex-1 flex flex-col">
        {/* Messages */}
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map(renderMessage)}
            
            {/* AI Suggestion Card */}
            <div className="bg-[#2D2D2D] rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <Badge variant="outline" className="text-purple-400 border-purple-400">
                  <Lightbulb size={12} className="mr-1" />
                  Suggestion
                </Badge>
                <span className="text-xs text-gray-400">2 min ago</span>
              </div>
              <p className="text-sm mb-2 text-gray-200">
                I notice you're missing error handling. Should I add try-catch blocks?
              </p>
              <div className="flex space-x-2">
                <Button 
                  size="sm" 
                  className="text-xs bg-blue-600 hover:bg-blue-700"
                  onClick={() => generateCode('optimize')}
                >
                  Apply
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-xs border-[#3C3C3C] text-gray-300 hover:bg-[#3C3C3C]"
                >
                  Ignore
                </Button>
              </div>
            </div>
            
            {isLoading && (
              <div className="flex">
                <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center mr-2 mt-1">
                  <Cpu size={16} className="text-white animate-pulse" />
                </div>
                <div className="bg-[#2D2D2D] rounded-lg p-3 text-sm text-gray-400">
                  <div className="loading-dots">Thinking</div>
                </div>
              </div>
            )}
          </div>
          <div ref={messagesEndRef} />
        </ScrollArea>

        {/* Input Area */}
        <div className="p-4 border-t border-[#3C3C3C]">
          <div className="relative">
            <Textarea
              ref={textareaRef}
              placeholder="Describe what you want to build or fix..."
              value={currentMessage}
              onChange={(e) => setCurrentMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              className="w-full bg-[#171717] border-[#3C3C3C] text-white placeholder-gray-400 resize-none focus:border-blue-500 pr-12"
              rows={3}
            />
            <Button
              onClick={sendMessage}
              disabled={!currentMessage.trim() || isLoading}
              className="absolute bottom-3 right-3 bg-blue-600 hover:bg-blue-700 p-2 h-8 w-8"
            >
              <Send size={14} />
            </Button>
          </div>
          
          <div className="flex items-center justify-between mt-2">
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                size="sm" 
                className="text-xs border-[#3C3C3C] text-gray-300 hover:bg-[#3C3C3C]"
                onClick={() => generateCode('generate')}
              >
                <Code size={12} className="mr-1" />
                Generate
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="text-xs border-[#3C3C3C] text-gray-300 hover:bg-[#3C3C3C]"
                onClick={() => generateCode('debug')}
              >
                <Bug size={12} className="mr-1" />
                Debug
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                className="text-xs border-[#3C3C3C] text-gray-300 hover:bg-[#3C3C3C]"
                onClick={() => generateCode('optimize')}
              >
                <Rocket size={12} className="mr-1" />
                Deploy
              </Button>
            </div>
            <span className="text-xs text-gray-400">⌘ + Enter</span>
          </div>
        </div>
      </div>
    </div>
  );
}
