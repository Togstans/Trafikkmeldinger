import { Button } from "@/components/ui/button";
import { X, FileCode, Circle } from "lucide-react";
import type { OpenTab } from "@/types/ide";

interface EditorTabsProps {
  tabs: OpenTab[];
  activeTab: string | null;
  onTabSelect: (tabId: string) => void;
  onTabClose: (tabId: string) => void;
}

export function EditorTabs({ tabs, activeTab, onTabSelect, onTabClose }: EditorTabsProps) {
  const getFileIcon = (fileName: string) => {
    const ext = fileName.split('.').pop()?.toLowerCase();
    const colorMap: Record<string, string> = {
      'js': 'text-yellow-400',
      'jsx': 'text-blue-400',
      'ts': 'text-blue-500',
      'tsx': 'text-blue-400',
      'py': 'text-green-400',
      'html': 'text-orange-400',
      'css': 'text-pink-400',
      'json': 'text-gray-400',
      'md': 'text-blue-300'
    };
    
    return colorMap[ext || ''] || 'text-gray-400';
  };

  return (
    <div className="bg-[#2D2D2D] border-b border-[#3C3C3C] flex">
      <div className="flex">
        {tabs.map((tab) => (
          <div
            key={tab.id}
            className={`px-4 py-2 text-sm flex items-center space-x-2 border-r border-[#3C3C3C] cursor-pointer transition-colors ${
              activeTab === tab.id 
                ? 'bg-[#171717] text-white' 
                : 'hover:bg-[#3C3C3C] text-gray-300'
            }`}
            onClick={() => onTabSelect(tab.id)}
          >
            <FileCode size={16} className={getFileIcon(tab.name)} />
            <span>{tab.name}</span>
            {tab.isDirty && (
              <Circle size={6} className="text-yellow-400 fill-current" />
            )}
            <Button
              variant="ghost"
              size="sm"
              className="p-0 h-4 w-4 text-gray-500 hover:text-white ml-2"
              onClick={(e) => {
                e.stopPropagation();
                onTabClose(tab.id);
              }}
            >
              <X size={12} />
            </Button>
          </div>
        ))}
      </div>
      <div className="flex-1"></div>
      {/* Live preview indicator */}
      <div className="px-4 py-2 text-sm flex items-center space-x-2">
        <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
        <span className="text-green-400">Live Preview Active</span>
      </div>
    </div>
  );
}
