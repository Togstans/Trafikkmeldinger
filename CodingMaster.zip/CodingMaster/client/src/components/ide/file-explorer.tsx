import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Folder, 
  FolderOpen, 
  File, 
  FileCode, 
  Plus, 
  FolderPlus, 
  RefreshCw,
  ChevronDown,
  ChevronRight,
  GitBranch,
  Check,
  Zap
} from "lucide-react";
import type { FileNode, Project } from "@/types/ide";

interface FileExplorerProps {
  project: Project | null;
  selectedFile: string | null;
  onFileSelect: (path: string) => void;
  onCreateFile: (path: string) => void;
  onCreateFolder: (path: string) => void;
}

export function FileExplorer({ 
  project, 
  selectedFile, 
  onFileSelect, 
  onCreateFile, 
  onCreateFolder 
}: FileExplorerProps) {
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(['', 'src', 'src/components']));

  const toggleFolder = (path: string) => {
    const newExpanded = new Set(expandedFolders);
    if (newExpanded.has(path)) {
      newExpanded.delete(path);
    } else {
      newExpanded.add(path);
    }
    setExpandedFolders(newExpanded);
  };

  const buildFileTree = (files: Record<string, any>): FileNode[] => {
    const tree: FileNode[] = [];
    const pathMap = new Map<string, FileNode>();

    // Create nodes for all paths
    Object.keys(files).forEach(path => {
      const parts = path.split('/');
      let currentPath = '';
      
      parts.forEach((part, index) => {
        const fullPath = currentPath ? `${currentPath}/${part}` : part;
        
        if (!pathMap.has(fullPath)) {
          const isFile = index === parts.length - 1;
          const node: FileNode = {
            name: part,
            type: isFile ? 'file' : 'folder',
            path: fullPath,
            children: isFile ? undefined : [],
            content: isFile ? files[path]?.content : undefined,
            language: isFile ? getLanguageFromPath(fullPath) : undefined
          };
          
          pathMap.set(fullPath, node);
          
          if (currentPath === '') {
            tree.push(node);
          } else {
            const parent = pathMap.get(currentPath);
            if (parent && parent.children) {
              parent.children.push(node);
            }
          }
        }
        
        currentPath = fullPath;
      });
    });

    return tree;
  };

  const getLanguageFromPath = (path: string): string => {
    const ext = path.split('.').pop()?.toLowerCase();
    const langMap: Record<string, string> = {
      'js': 'javascript',
      'jsx': 'javascript',
      'ts': 'typescript',
      'tsx': 'typescript',
      'py': 'python',
      'html': 'html',
      'css': 'css',
      'json': 'json',
      'md': 'markdown'
    };
    return langMap[ext || ''] || 'plaintext';
  };

  const getFileIcon = (fileName: string) => {
    const ext = fileName.split('.').pop()?.toLowerCase();
    const iconMap: Record<string, { icon: typeof FileCode, color: string }> = {
      'js': { icon: FileCode, color: 'text-yellow-400' },
      'jsx': { icon: FileCode, color: 'text-blue-400' },
      'ts': { icon: FileCode, color: 'text-blue-500' },
      'tsx': { icon: FileCode, color: 'text-blue-400' },
      'py': { icon: FileCode, color: 'text-green-400' },
      'html': { icon: FileCode, color: 'text-orange-400' },
      'css': { icon: FileCode, color: 'text-pink-400' },
      'json': { icon: File, color: 'text-gray-400' },
      'md': { icon: File, color: 'text-blue-300' }
    };
    
    const config = iconMap[ext || ''] || { icon: File, color: 'text-gray-400' };
    return config;
  };

  const renderFileNode = (node: FileNode, depth: number = 0): React.ReactNode => {
    const isExpanded = expandedFolders.has(node.path);
    const isSelected = selectedFile === node.path;
    const { icon: Icon, color } = getFileIcon(node.name);

    return (
      <div key={node.path}>
        <div
          className={`flex items-center space-x-1 py-1 px-2 cursor-pointer rounded transition-colors file-tree-item ${
            isSelected ? 'bg-[#2D2D2D]' : 'hover:bg-[#3C3C3C]'
          }`}
          style={{ paddingLeft: `${depth * 16 + 8}px` }}
          onClick={() => {
            if (node.type === 'folder') {
              toggleFolder(node.path);
            } else {
              onFileSelect(node.path);
            }
          }}
        >
          {node.type === 'folder' && (
            <>
              {isExpanded ? (
                <ChevronDown size={12} className="text-gray-500" />
              ) : (
                <ChevronRight size={12} className="text-gray-500" />
              )}
              {isExpanded ? (
                <FolderOpen size={16} className="text-yellow-500" />
              ) : (
                <Folder size={16} className="text-yellow-500" />
              )}
            </>
          )}
          {node.type === 'file' && (
            <>
              <div style={{ width: '12px' }} /> {/* Spacer for alignment */}
              <Icon size={16} className={color} />
            </>
          )}
          <span className="text-sm text-gray-200">{node.name}</span>
        </div>
        
        {node.type === 'folder' && isExpanded && node.children && (
          <div>
            {node.children.map(child => renderFileNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  if (!project) {
    return (
      <div className="w-64 bg-[#1E1E1E] border-r border-[#3C3C3C] flex flex-col">
        <div className="p-4 text-center text-gray-400">
          <FolderOpen size={48} className="mx-auto mb-2 opacity-50" />
          <p>No project loaded</p>
        </div>
      </div>
    );
  }

  const fileTree = buildFileTree(project.files);

  return (
    <div className="w-64 bg-[#1E1E1E] border-r border-[#3C3C3C] flex flex-col">
      {/* Sidebar Header */}
      <div className="p-3 border-b border-[#3C3C3C]">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-gray-300">Explorer</h3>
          <div className="flex space-x-1">
            <Button 
              variant="ghost" 
              size="sm" 
              className="p-1 h-6 w-6 text-gray-400 hover:text-white hover:bg-[#3C3C3C]"
              onClick={() => onCreateFile('')}
            >
              <Plus size={12} />
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="p-1 h-6 w-6 text-gray-400 hover:text-white hover:bg-[#3C3C3C]"
              onClick={() => onCreateFolder('')}
            >
              <FolderPlus size={12} />
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className="p-1 h-6 w-6 text-gray-400 hover:text-white hover:bg-[#3C3C3C]"
            >
              <RefreshCw size={12} />
            </Button>
          </div>
        </div>
      </div>

      {/* File Tree */}
      <ScrollArea className="flex-1 p-2">
        <div className="space-y-1 text-sm">
          {/* Project root */}
          <div
            className="flex items-center space-x-1 py-1 px-2 hover:bg-[#3C3C3C] rounded cursor-pointer"
            onClick={() => toggleFolder('')}
          >
            {expandedFolders.has('') ? (
              <ChevronDown size={12} className="text-gray-500" />
            ) : (
              <ChevronRight size={12} className="text-gray-500" />
            )}
            <Folder size={16} className="text-blue-500" />
            <span className="font-medium text-gray-200">{project.name}</span>
          </div>
          
          {/* File tree */}
          {expandedFolders.has('') && (
            <div className="ml-4 space-y-1">
              {fileTree.map(node => renderFileNode(node, 0))}
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Git Status */}
      <div className="p-3 border-t border-[#3C3C3C]">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center space-x-2">
            <GitBranch size={14} className="text-orange-500" />
            <span className="text-gray-300">main</span>
            <span className="text-green-400 flex items-center">
              <Check size={12} className="mr-1" />
              3
            </span>
            <span className="text-yellow-400 flex items-center">
              <Zap size={12} className="mr-1" />
              2
            </span>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            className="p-1 h-5 w-5 text-gray-400 hover:text-white"
          >
            <RefreshCw size={10} />
          </Button>
        </div>
      </div>
    </div>
  );
}
