import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Brain, Rocket, Settings, UserCircle, FolderOpen, ChevronRight, Circle } from "lucide-react";

interface NavigationProps {
  projectName: string;
  onDeploy: () => void;
  onSettings: () => void;
}

export function Navigation({ projectName, onDeploy, onSettings }: NavigationProps) {
  const collaborators = [
    { id: '1', name: 'John Doe', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=32&h=32&fit=crop&crop=face', online: true },
    { id: '2', name: 'Jane Smith', avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b4c0?w=32&h=32&fit=crop&crop=face', online: true },
    { id: '3', name: 'Mike Johnson', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=32&h=32&fit=crop&crop=face', online: false }
  ];

  return (
    <nav className="bg-[#1E1E1E] border-b border-[#3C3C3C] px-4 py-2 flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
            <Brain className="text-white" size={16} />
          </div>
          <span className="text-xl font-bold text-white">Master AI</span>
          <Badge variant="secondary" className="bg-purple-600 text-white text-xs">
            PRO
          </Badge>
        </div>
        
        <div className="flex items-center space-x-2 text-sm">
          <Button variant="ghost" size="sm" className="text-gray-300 hover:text-white hover:bg-[#3C3C3C]">
            <FolderOpen size={16} className="mr-1" />
            {projectName}
          </Button>
          <ChevronRight size={16} className="text-gray-500" />
          <span className="text-gray-400">src/components</span>
        </div>
      </div>

      <div className="flex items-center space-x-4">
        {/* Collaboration Status */}
        <div className="flex items-center space-x-2">
          <div className="flex -space-x-2">
            {collaborators.slice(0, 3).map((user) => (
              <Avatar key={user.id} className="w-6 h-6 border-2 border-[#1E1E1E]">
                <AvatarImage src={user.avatar} alt={user.name} />
                <AvatarFallback className="text-xs">
                  {user.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
            ))}
          </div>
          <Badge variant="outline" className="bg-green-600 text-white border-green-600 text-xs">
            <Circle size={8} className="mr-1 fill-current" />
            Live
          </Badge>
        </div>

        <div className="flex items-center space-x-2">
          <Button 
            onClick={onDeploy}
            className="bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium"
            size="sm"
          >
            <Rocket size={16} className="mr-1" />
            Deploy
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={onSettings}
            className="text-gray-300 hover:text-white hover:bg-[#3C3C3C]"
          >
            <Settings size={16} />
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            className="text-gray-300 hover:text-white hover:bg-[#3C3C3C]"
          >
            <UserCircle size={20} />
          </Button>
        </div>
      </div>
    </nav>
  );
}
