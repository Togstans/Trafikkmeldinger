import { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Terminal as TerminalIcon, 
  List, 
  AlertTriangle, 
  Eye, 
  X 
} from "lucide-react";

interface TerminalLine {
  id: string;
  type: 'command' | 'output' | 'error' | 'success';
  content: string;
  timestamp: Date;
}

interface TerminalProps {
  isVisible: boolean;
  onToggle: () => void;
}

export function Terminal({ isVisible, onToggle }: TerminalProps) {
  const [activeTab, setActiveTab] = useState<'terminal' | 'output' | 'problems' | 'preview'>('terminal');
  const [lines, setLines] = useState<TerminalLine[]>([
    {
      id: '1',
      type: 'command',
      content: 'masterai@cloud:~/my-social-app$ npm install',
      timestamp: new Date(Date.now() - 60000)
    },
    {
      id: '2',
      type: 'output',
      content: '📦 Installing dependencies...',
      timestamp: new Date(Date.now() - 55000)
    },
    {
      id: '3',
      type: 'success',
      content: '✅ Added 847 packages in 12.3s',
      timestamp: new Date(Date.now() - 45000)
    },
    {
      id: '4',
      type: 'command',
      content: 'masterai@cloud:~/my-social-app$ npm run dev',
      timestamp: new Date(Date.now() - 30000)
    },
    {
      id: '5',
      type: 'output',
      content: '🚀 Starting development server...',
      timestamp: new Date(Date.now() - 25000)
    },
    {
      id: '6',
      type: 'success',
      content: '✨ Local: http://localhost:3000',
      timestamp: new Date(Date.now() - 20000)
    },
    {
      id: '7',
      type: 'success',
      content: '📡 Network: http://192.168.1.100:3000',
      timestamp: new Date(Date.now() - 15000)
    },
    {
      id: '8',
      type: 'output',
      content: '⚡ AI: Optimizing bundle size...',
      timestamp: new Date(Date.now() - 10000)
    }
  ]);
  const [currentCommand, setCurrentCommand] = useState('');
  const [cursorVisible, setCursorVisible] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Cursor blinking effect
  useEffect(() => {
    const interval = setInterval(() => {
      setCursorVisible(prev => !prev);
    }, 500);
    return () => clearInterval(interval);
  }, []);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [lines]);

  const handleCommand = (command: string) => {
    const newLine: TerminalLine = {
      id: Date.now().toString(),
      type: 'command',
      content: `masterai@cloud:~/my-social-app$ ${command}`,
      timestamp: new Date()
    };

    setLines(prev => [...prev, newLine]);

    // Simulate command responses
    setTimeout(() => {
      const responses: Record<string, TerminalLine[]> = {
        'ls': [
          {
            id: (Date.now() + 1).toString(),
            type: 'output',
            content: 'src/  package.json  README.md  Dockerfile  .gitignore',
            timestamp: new Date()
          }
        ],
        'npm start': [
          {
            id: (Date.now() + 1).toString(),
            type: 'output',
            content: '🚀 Starting development server...',
            timestamp: new Date()
          },
          {
            id: (Date.now() + 2).toString(),
            type: 'success',
            content: '✨ Server running on http://localhost:3000',
            timestamp: new Date()
          }
        ],
        'git status': [
          {
            id: (Date.now() + 1).toString(),
            type: 'output',
            content: 'On branch main\nChanges not staged for commit:\n  modified: src/components/Feed.jsx',
            timestamp: new Date()
          }
        ]
      };

      const response = responses[command] || [
        {
          id: (Date.now() + 1).toString(),
          type: 'output',
          content: `Command '${command}' executed successfully`,
          timestamp: new Date()
        }
      ];

      setLines(prev => [...prev, ...response]);
    }, 500);
  };

  const getLineColor = (type: TerminalLine['type']) => {
    switch (type) {
      case 'command':
        return 'text-green-400';
      case 'output':
        return 'text-blue-400';
      case 'error':
        return 'text-red-400';
      case 'success':
        return 'text-green-400';
      default:
        return 'text-gray-300';
    }
  };

  const problems = [
    { type: 'error', file: 'src/components/Feed.jsx', line: 16, message: 'React Hook useEffect has a missing dependency' },
    { type: 'warning', file: 'src/App.jsx', line: 8, message: 'Unused import statement' }
  ];

  if (!isVisible) return null;

  return (
    <div className="h-64 bg-[#1E1E1E] border-t border-[#3C3C3C] flex flex-col">
      {/* Terminal Tabs */}
      <div className="flex border-b border-[#3C3C3C]">
        <Button
          variant="ghost"
          size="sm"
          className={`px-4 py-2 text-sm rounded-none border-r border-[#3C3C3C] ${
            activeTab === 'terminal' 
              ? 'bg-[#171717] text-white' 
              : 'text-gray-400 hover:text-white hover:bg-[#2D2D2D]'
          }`}
          onClick={() => setActiveTab('terminal')}
        >
          <TerminalIcon size={14} className="mr-1" />
          Terminal
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className={`px-4 py-2 text-sm rounded-none border-r border-[#3C3C3C] ${
            activeTab === 'output' 
              ? 'bg-[#171717] text-white' 
              : 'text-gray-400 hover:text-white hover:bg-[#2D2D2D]'
          }`}
          onClick={() => setActiveTab('output')}
        >
          <List size={14} className="mr-1" />
          Output
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className={`px-4 py-2 text-sm rounded-none border-r border-[#3C3C3C] ${
            activeTab === 'problems' 
              ? 'bg-[#171717] text-white' 
              : 'text-gray-400 hover:text-white hover:bg-[#2D2D2D]'
          }`}
          onClick={() => setActiveTab('problems')}
        >
          <AlertTriangle size={14} className="mr-1" />
          Problems ({problems.length})
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className={`px-4 py-2 text-sm rounded-none ${
            activeTab === 'preview' 
              ? 'bg-[#171717] text-white' 
              : 'text-gray-400 hover:text-white hover:bg-[#2D2D2D]'
          }`}
          onClick={() => setActiveTab('preview')}
        >
          <Eye size={14} className="mr-1" />
          Preview
        </Button>
        <div className="flex-1"></div>
        <Button
          variant="ghost"
          size="sm"
          className="px-2 py-2 text-gray-400 hover:text-white hover:bg-[#2D2D2D]"
          onClick={onToggle}
        >
          <X size={14} />
        </Button>
      </div>

      {/* Terminal Content */}
      <div className="flex-1 overflow-hidden">
        {activeTab === 'terminal' && (
          <ScrollArea className="h-full">
            <div ref={scrollRef} className="p-4 font-mono text-sm terminal space-y-1">
              {lines.map((line) => (
                <div key={line.id} className={getLineColor(line.type)}>
                  {line.content}
                </div>
              ))}
              <div className="flex items-center text-green-400">
                <span>masterai@cloud:~/my-social-app$ </span>
                <input
                  type="text"
                  value={currentCommand}
                  onChange={(e) => setCurrentCommand(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      handleCommand(currentCommand);
                      setCurrentCommand('');
                    }
                  }}
                  className="bg-transparent border-none outline-none text-green-400 flex-1 ml-1"
                  placeholder=""
                />
                <span className={`w-2 h-4 bg-green-400 ml-1 ${cursorVisible ? 'opacity-100' : 'opacity-0'}`} />
              </div>
            </div>
          </ScrollArea>
        )}

        {activeTab === 'output' && (
          <ScrollArea className="h-full">
            <div className="p-4 font-mono text-sm text-gray-300 space-y-1">
              <div>Building project...</div>
              <div className="text-blue-400">Webpack compiled successfully</div>
              <div className="text-green-400">✓ Build completed in 2.3s</div>
              <div>Starting development server...</div>
              <div className="text-yellow-400">⚡ Hot reload enabled</div>
            </div>
          </ScrollArea>
        )}

        {activeTab === 'problems' && (
          <ScrollArea className="h-full">
            <div className="p-4 space-y-2">
              {problems.map((problem, index) => (
                <div key={index} className="flex items-start space-x-2 text-sm">
                  <div className={`w-4 h-4 rounded-full flex items-center justify-center text-xs ${
                    problem.type === 'error' ? 'bg-red-500' : 'bg-yellow-500'
                  }`}>
                    {problem.type === 'error' ? '✕' : '⚠'}
                  </div>
                  <div className="flex-1">
                    <div className="text-gray-200">{problem.message}</div>
                    <div className="text-gray-400 text-xs">
                      {problem.file}:{problem.line}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}

        {activeTab === 'preview' && (
          <div className="h-full bg-white flex items-center justify-center">
            <div className="text-gray-600 text-center">
              <Eye size={48} className="mx-auto mb-2 opacity-50" />
              <p>Live preview will appear here</p>
              <p className="text-sm">http://localhost:3000</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
