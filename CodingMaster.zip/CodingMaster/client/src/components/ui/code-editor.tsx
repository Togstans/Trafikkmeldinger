import { useEffect, useRef, useState } from 'react';
import { Loader2 } from 'lucide-react';

interface CodeEditorProps {
  value: string;
  onChange?: (value: string) => void;
  language?: string;
  height?: string;
  theme?: 'light' | 'dark';
  readOnly?: boolean;
}

export function CodeEditor({ 
  value, 
  onChange, 
  language = 'javascript', 
  height = '100%',
  theme = 'dark',
  readOnly = false
}: CodeEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [editor, setEditor] = useState<any>(null);

  useEffect(() => {
    let mounted = true;

    async function initMonaco() {
      try {
        // Dynamic import to avoid SSR issues
        const monaco = await import('monaco-editor');
        
        if (!mounted || !editorRef.current) return;

        // Configure Monaco Environment
        (window as any).MonacoEnvironment = {
          getWorkerUrl: () => {
            return `data:text/javascript;charset=utf-8,${encodeURIComponent(`
              self.MonacoEnvironment = {
                baseUrl: 'https://unpkg.com/monaco-editor@0.45.0/min/'
              };
              importScripts('https://unpkg.com/monaco-editor@0.45.0/min/vs/base/worker/workerMain.js');
            `)}`;
          }
        };

        // Define custom theme
        monaco.editor.defineTheme('master-ai-dark', {
          base: 'vs-dark',
          inherit: true,
          rules: [
            { token: 'comment', foreground: '6A737D' },
            { token: 'keyword', foreground: 'F97583' },
            { token: 'string', foreground: '9ECBFF' },
            { token: 'number', foreground: '79B8FF' },
            { token: 'regexp', foreground: '7C3AED' },
            { token: 'type', foreground: 'B392F0' },
            { token: 'class', foreground: 'FFAB70' },
            { token: 'function', foreground: 'B392F0' },
            { token: 'variable', foreground: 'E1E4E8' },
            { token: 'constant', foreground: '79B8FF' }
          ],
          colors: {
            'editor.background': '#171717',
            'editor.foreground': '#E1E4E8',
            'editor.lineHighlightBackground': '#2D2D2D',
            'editor.selectionBackground': '#3392FF44',
            'editor.inactiveSelectionBackground': '#3392FF22',
            'editorCursor.foreground': '#E1E4E8',
            'editorWhitespace.foreground': '#6A737D'
          }
        });

        // Create editor instance
        const editorInstance = monaco.editor.create(editorRef.current, {
          value,
          language,
          theme: theme === 'dark' ? 'master-ai-dark' : 'vs',
          automaticLayout: true,
          fontSize: 14,
          fontFamily: 'JetBrains Mono, Monaco, Consolas, monospace',
          minimap: { enabled: false },
          scrollBeyondLastLine: false,
          wordWrap: 'on',
          lineNumbers: 'on',
          glyphMargin: false,
          folding: true,
          lineDecorationsWidth: 10,
          lineNumbersMinChars: 3,
          renderLineHighlight: 'line',
          readOnly,
          contextmenu: true,
          smoothScrolling: true,
          cursorBlinking: 'smooth',
          cursorSmoothCaretAnimation: 'on'
        });

        // Handle content changes
        editorInstance.onDidChangeModelContent(() => {
          const newValue = editorInstance.getValue();
          onChange?.(newValue);
        });

        setEditor(editorInstance);
        setIsLoading(false);

        return () => {
          editorInstance.dispose();
        };
      } catch (error) {
        console.error('Failed to initialize Monaco Editor:', error);
        setIsLoading(false);
      }
    }

    initMonaco();

    return () => {
      mounted = false;
      if (editor) {
        editor.dispose();
      }
    };
  }, []);

  useEffect(() => {
    if (editor && value !== editor.getValue()) {
      editor.setValue(value);
    }
  }, [value, editor]);

  useEffect(() => {
    if (editor) {
      const model = editor.getModel();
      if (model) {
        // Dynamic import to avoid module issues
        import('monaco-editor').then((monaco) => {
          monaco.editor.setModelLanguage(model, language);
        });
      }
    }
  }, [language, editor]);

  if (isLoading) {
    return (
      <div 
        style={{ height }}
        className="bg-[#171717] border border-gray-700 rounded-lg flex items-center justify-center"
      >
        <div className="flex items-center space-x-2 text-gray-400">
          <Loader2 size={20} className="animate-spin" />
          <span>Loading editor...</span>
        </div>
      </div>
    );
  }

  return (
    <div 
      ref={editorRef} 
      style={{ height }}
      className="border border-gray-700 rounded-lg overflow-hidden"
    />
  );
}