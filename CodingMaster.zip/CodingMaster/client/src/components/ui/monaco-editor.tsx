import { useEffect, useRef } from 'react';
import * as monaco from 'monaco-editor';

// Configure Monaco Environment for Vite
(window as any).MonacoEnvironment = {
  getWorkerUrl: function (moduleId: string, label: string) {
    if (label === 'json') {
      return '/monaco-editor/esm/vs/language/json/json.worker.js';
    }
    if (label === 'css' || label === 'scss' || label === 'less') {
      return '/monaco-editor/esm/vs/language/css/css.worker.js';
    }
    if (label === 'html' || label === 'handlebars' || label === 'razor') {
      return '/monaco-editor/esm/vs/language/html/html.worker.js';
    }
    if (label === 'typescript' || label === 'javascript') {
      return '/monaco-editor/esm/vs/language/typescript/ts.worker.js';
    }
    return '/monaco-editor/esm/vs/editor/editor.worker.js';
  }
};

interface MonacoEditorProps {
  value: string;
  onChange?: (value: string) => void;
  language?: string;
  theme?: string;
  options?: monaco.editor.IStandaloneEditorConstructionOptions;
  height?: string;
}

export function MonacoEditor({ 
  value, 
  onChange, 
  language = 'javascript', 
  theme = 'vs-dark',
  options = {},
  height = '100%'
}: MonacoEditorProps) {
  const editorRef = useRef<monaco.editor.IStandaloneCodeEditor | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Configure Monaco Editor theme to match our dark theme
    monaco.editor.defineTheme('master-ai-dark', {
      base: 'vs-dark',
      inherit: true,
      rules: [
        { token: 'comment', foreground: '6A737D' },
        { token: 'keyword', foreground: 'F97583' },
        { token: 'string', foreground: '9ECBFF' },
        { token: 'number', foreground: '79B8FF' },
        { token: 'regexp', foreground: '7C3AED' },
        { token: 'type', foreground: 'B392F0' },
        { token: 'class', foreground: 'FFAB70' },
        { token: 'function', foreground: 'B392F0' },
        { token: 'variable', foreground: 'E1E4E8' },
        { token: 'constant', foreground: '79B8FF' }
      ],
      colors: {
        'editor.background': '#171717',
        'editor.foreground': '#E1E4E8',
        'editor.lineHighlightBackground': '#2D2D2D',
        'editor.selectionBackground': '#3392FF44',
        'editor.inactiveSelectionBackground': '#3392FF22',
        'editorCursor.foreground': '#E1E4E8',
        'editorWhitespace.foreground': '#6A737D'
      }
    });

    const editor = monaco.editor.create(containerRef.current, {
      value,
      language,
      theme: 'master-ai-dark',
      automaticLayout: true,
      fontSize: 14,
      fontFamily: 'JetBrains Mono, Monaco, Consolas, monospace',
      minimap: { enabled: false },
      scrollBeyondLastLine: false,
      wordWrap: 'on',
      lineNumbers: 'on',
      glyphMargin: false,
      folding: true,
      lineDecorationsWidth: 10,
      lineNumbersMinChars: 3,
      renderLineHighlight: 'line',
      ...options
    });

    editorRef.current = editor;

    // Handle content changes
    const disposable = editor.onDidChangeModelContent(() => {
      const newValue = editor.getValue();
      onChange?.(newValue);
    });

    return () => {
      disposable.dispose();
      editor.dispose();
    };
  }, []);

  useEffect(() => {
    if (editorRef.current && value !== editorRef.current.getValue()) {
      editorRef.current.setValue(value);
    }
  }, [value]);

  useEffect(() => {
    if (editorRef.current) {
      monaco.editor.setModelLanguage(editorRef.current.getModel()!, language);
    }
  }, [language]);

  return (
    <div 
      ref={containerRef} 
      style={{ height }}
      className="border border-gray-700 rounded-lg overflow-hidden"
    />
  );
}
