import { useRef, useEffect } from 'react';

interface SimpleEditorProps {
  value: string;
  onChange?: (value: string) => void;
  language?: string;
  height?: string;
  theme?: 'light' | 'dark';
  readOnly?: boolean;
}

export function SimpleEditor({ 
  value, 
  onChange, 
  language = 'javascript', 
  height = '100%',
  theme = 'dark',
  readOnly = false
}: SimpleEditorProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (textareaRef.current && value !== textareaRef.current.value) {
      textareaRef.current.value = value;
    }
  }, [value]);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onChange?.(e.target.value);
  };

  const getLanguageInfo = (lang: string) => {
    const languages: Record<string, { name: string; color: string }> = {
      javascript: { name: 'JavaScript', color: 'text-yellow-400' },
      typescript: { name: 'TypeScript', color: 'text-blue-400' },
      python: { name: 'Python', color: 'text-green-400' },
      html: { name: 'HTML', color: 'text-orange-400' },
      css: { name: 'CSS', color: 'text-pink-400' },
      json: { name: 'JSON', color: 'text-gray-400' },
      markdown: { name: 'Markdown', color: 'text-blue-300' }
    };
    return languages[lang] || { name: 'Text', color: 'text-gray-400' };
  };

  const langInfo = getLanguageInfo(language);

  return (
    <div 
      style={{ height }}
      className="flex flex-col bg-[#171717] border border-gray-700 rounded-lg overflow-hidden"
    >
      {/* Editor Header */}
      <div className="bg-[#1E1E1E] px-3 py-2 border-b border-gray-700 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${langInfo.color.replace('text-', 'bg-')}`} />
          <span className="text-xs text-gray-400">{langInfo.name}</span>
        </div>
        <div className="text-xs text-gray-500">
          Lines: {value.split('\n').length}
        </div>
      </div>
      
      {/* Editor Content */}
      <textarea
        ref={textareaRef}
        defaultValue={value}
        onChange={handleChange}
        readOnly={readOnly}
        placeholder={`Start typing ${langInfo.name.toLowerCase()} code...`}
        className={`
          flex-1 w-full p-4 resize-none outline-none font-mono text-sm leading-relaxed
          bg-[#171717] text-gray-200 placeholder-gray-500
          ${theme === 'dark' ? 'bg-[#171717] text-gray-200' : 'bg-white text-gray-900'}
        `}
        style={{
          fontFamily: 'JetBrains Mono, Monaco, Consolas, monospace',
          fontSize: '14px',
          lineHeight: '1.6',
          tabSize: 2
        }}
        spellCheck={false}
      />
      
      {/* Status Bar */}
      <div className="bg-[#1E1E1E] px-3 py-1 border-t border-gray-700 flex items-center justify-between text-xs text-gray-500">
        <div className="flex items-center space-x-4">
          <span>UTF-8</span>
          <span>{language.toUpperCase()}</span>
        </div>
        <div className="flex items-center space-x-4">
          <span>Ln {value.substring(0, value.lastIndexOf('\n')).split('\n').length}</span>
          <span>Col {value.length - value.lastIndexOf('\n')}</span>
        </div>
      </div>
    </div>
  );
}