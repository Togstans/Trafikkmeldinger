import { apiRequest } from "./queryClient";
import type { CodeGenerationResult, AIMessage } from "../types/ide";

export class AIService {
  static async generateCode(
    prompt: string,
    fileType?: string,
    projectContext?: string
  ): Promise<CodeGenerationResult> {
    const response = await apiRequest("POST", "/api/ai/generate", {
      prompt,
      fileType,
      projectContext
    });
    
    return await response.json();
  }

  static async sendChatMessage(
    message: string,
    projectId?: number,
    conversationHistory?: Array<{role: string, content: string}>
  ): Promise<{ response: string; timestamp: string }> {
    const response = await apiRequest("POST", "/api/ai/chat", {
      message,
      projectId,
      conversationHistory
    });
    
    return await response.json();
  }

  static async optimizeCode(code: string, language: string): Promise<string> {
    const prompt = `Optimize this ${language} code for better performance and readability:\n\n${code}`;
    const result = await this.generateCode(prompt, language);
    return result.code;
  }

  static async debugCode(code: string, error: string, language: string): Promise<string> {
    const prompt = `Debug this ${language} code that has the following error: ${error}\n\nCode:\n${code}`;
    const result = await this.generateCode(prompt, language);
    return result.code;
  }

  static async explainCode(code: string, language: string): Promise<string> {
    const response = await this.sendChatMessage(
      `Explain this ${language} code:\n\n${code}`
    );
    return response.response;
  }
}
