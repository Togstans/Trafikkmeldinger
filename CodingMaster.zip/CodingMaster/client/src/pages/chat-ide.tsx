import { useState, useRef, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Send, 
  Paperclip, 
  Layers, 
  Wand2, 
  Brain,
  Code,
  Globe,
  Smartphone,
  Database,
  Settings,
  Sparkles
} from "lucide-react";
import { AIService } from "@/lib/ai-service";
import { apiRequest } from "@/lib/queryClient";

interface ChatMessage {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  isGenerating?: boolean;
}

export default function ChatIDE() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Create new project mutation
  const createProjectMutation = useMutation({
    mutationFn: async ({ name, description, template }: { name: string; description: string; template: string }) => {
      const response = await apiRequest('POST', '/api/projects', { name, description, template });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
    }
  });

  const handleSendMessage = async () => {
    if (!currentMessage.trim() || isGenerating) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: currentMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setCurrentMessage('');
    setIsGenerating(true);

    try {
      // Add generating message
      const generatingMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: '',
        timestamp: new Date(),
        isGenerating: true
      };
      setMessages(prev => [...prev, generatingMessage]);

      // Check if this is a project creation request
      const isCreationRequest = currentMessage.toLowerCase().includes('create') || 
                               currentMessage.toLowerCase().includes('build') ||
                               currentMessage.toLowerCase().includes('make');

      if (isCreationRequest) {
        // Generate project name from prompt
        const projectName = extractProjectName(currentMessage);
        
        // Create project
        const project = await createProjectMutation.mutateAsync({
          name: projectName,
          description: currentMessage,
          template: detectTemplate(currentMessage)
        });

        // Generate initial code
        const codeResult = await AIService.generateCode(
          currentMessage,
          detectTemplate(currentMessage),
          `Project: ${projectName}`
        );

        const responseContent = `I've created "${projectName}" for you! Here's what I built:

**Project Structure:**
- ${codeResult.fileName}
- package.json with dependencies
- Basic project setup

**Key Features:**
${codeResult.explanation}

**Dependencies Added:**
${codeResult.dependencies.map(dep => `• ${dep}`).join('\n')}

Your project is ready to use! You can now ask me to add features, fix issues, or deploy it.`;

        // Update the generating message
        setMessages(prev => prev.map(msg => 
          msg.isGenerating 
            ? { ...msg, content: responseContent, isGenerating: false }
            : msg
        ));
      } else {
        // Regular chat response
        const response = await AIService.sendChatMessage(currentMessage);
        
        setMessages(prev => prev.map(msg => 
          msg.isGenerating 
            ? { ...msg, content: response.response, isGenerating: false }
            : msg
        ));
      }
    } catch (error) {
      console.error('Failed to process message:', error);
      setMessages(prev => prev.map(msg => 
        msg.isGenerating 
          ? { ...msg, content: 'Sorry, I encountered an error. Please try again.', isGenerating: false }
          : msg
      ));
    } finally {
      setIsGenerating(false);
    }
  };

  const extractProjectName = (prompt: string): string => {
    // Simple extraction logic - can be enhanced
    const words = prompt.toLowerCase().split(' ');
    const projectTypes = ['app', 'website', 'site', 'application', 'tool', 'dashboard', 'platform'];
    
    for (let i = 0; i < words.length; i++) {
      if (projectTypes.includes(words[i]) && i > 0) {
        return words[i - 1] + '-' + words[i];
      }
    }
    
    return 'my-project';
  };

  const detectTemplate = (prompt: string): string => {
    const lower = prompt.toLowerCase();
    if (lower.includes('react') || lower.includes('component')) return 'react';
    if (lower.includes('api') || lower.includes('server') || lower.includes('backend')) return 'node';
    if (lower.includes('website') || lower.includes('landing')) return 'react';
    return 'react';
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const quickPrompts = [
    { icon: Globe, text: "Build a landing page", color: "bg-blue-500" },
    { icon: Smartphone, text: "Create a mobile app", color: "bg-green-500" },
    { icon: Database, text: "Build a dashboard", color: "bg-purple-500" },
    { icon: Code, text: "Generate an API", color: "bg-orange-500" }
  ];

  return (
    <div className="h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex flex-col">
      {/* Header */}
      <div className="bg-gray-900/50 backdrop-blur-sm border-b border-gray-700 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
              <Brain className="text-white" size={20} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Master AI</h1>
              <p className="text-gray-400 text-sm">Your AI Coding Agent</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Badge variant="outline" className="bg-purple-600/20 text-purple-300 border-purple-500">
              <Sparkles size={12} className="mr-1" />
              PRO
            </Badge>
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-gray-400 hover:text-white"
              onClick={() => window.location.href = '/admin'}
            >
              <Settings size={16} />
            </Button>
          </div>
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col max-w-4xl mx-auto w-full px-6">
        {messages.length === 0 ? (
          /* Welcome Screen */
          <div className="flex-1 flex flex-col items-center justify-center space-y-8">
            <div className="text-center space-y-4">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto">
                <Wand2 className="text-white" size={32} />
              </div>
              <h2 className="text-3xl font-bold text-white">What would you like to build?</h2>
              <p className="text-gray-400 text-lg max-w-2xl">
                Describe any app, website, or tool you want to create. I'll build it for you with modern code and best practices.
              </p>
            </div>

            {/* Quick Start Options */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 w-full max-w-2xl">
              {quickPrompts.map((prompt, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="h-24 flex-col space-y-2 border-gray-600 hover:border-gray-500 hover:bg-gray-800/50"
                  onClick={() => setCurrentMessage(prompt.text)}
                >
                  <div className={`w-8 h-8 ${prompt.color} rounded-lg flex items-center justify-center`}>
                    <prompt.icon className="text-white" size={16} />
                  </div>
                  <span className="text-sm text-gray-300">{prompt.text}</span>
                </Button>
              ))}
            </div>
          </div>
        ) : (
          /* Messages */
          <ScrollArea className="flex-1 py-6">
            <div className="space-y-6">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-3xl ${
                    message.type === 'user' 
                      ? 'bg-blue-600 text-white ml-12' 
                      : 'bg-gray-800 text-gray-200 mr-12'
                  } rounded-2xl px-6 py-4`}>
                    {message.isGenerating ? (
                      <div className="flex items-center space-x-2">
                        <div className="flex space-x-1">
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                          <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                        </div>
                        <span className="text-gray-400">Generating...</span>
                      </div>
                    ) : (
                      <div className="whitespace-pre-wrap">{message.content}</div>
                    )}
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>
        )}

        {/* Input Area */}
        <div className="py-6">
          <div className="relative">
            <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-600 rounded-2xl p-4">
              <Textarea
                ref={textareaRef}
                placeholder="Describe an app or site you want to create..."
                value={currentMessage}
                onChange={(e) => setCurrentMessage(e.target.value)}
                onKeyDown={handleKeyDown}
                className="w-full bg-transparent border-none text-white placeholder-gray-400 resize-none focus:outline-none text-lg leading-relaxed"
                rows={3}
                disabled={isGenerating}
              />
              <div className="flex items-center justify-between mt-3">
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white p-2">
                    <Layers size={16} />
                  </Button>
                  <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white p-2">
                    <Paperclip size={16} />
                  </Button>
                </div>
                <div className="flex items-center space-x-3">
                  <span className="text-xs text-gray-500">⌘ + Enter to send</span>
                  <Button
                    onClick={handleSendMessage}
                    disabled={!currentMessage.trim() || isGenerating}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-xl"
                  >
                    <Send size={16} />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}