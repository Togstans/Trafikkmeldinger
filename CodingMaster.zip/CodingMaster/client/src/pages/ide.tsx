import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from "@/components/ui/button";
import { SimpleEditor } from "@/components/ui/simple-editor";
import { Navigation } from "@/components/ide/navigation";
import { FileExplorer } from "@/components/ide/file-explorer";
import { AIChat } from "@/components/ide/ai-chat";
import { Terminal } from "@/components/ide/terminal";
import { EditorTabs } from "@/components/ide/editor-tabs";
import { Brain } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { AIService } from "@/lib/ai-service";
import type { Project, OpenTab } from "@/types/ide";

export default function IDE() {
  const [selectedFile, setSelectedFile] = useState<string | null>('src/components/Feed.jsx');
  const [openTabs, setOpenTabs] = useState<OpenTab[]>([
    {
      id: 'feed',
      name: 'Feed.jsx',
      path: 'src/components/Feed.jsx',
      content: '',
      language: 'javascript'
    }
  ]);
  const [activeTab, setActiveTab] = useState<string | null>('feed');
  const [isTerminalVisible, setIsTerminalVisible] = useState(true);
  const [showAIFloat, setShowAIFloat] = useState(false);
  
  const queryClient = useQueryClient();

  // Fetch projects
  const { data: projects } = useQuery({
    queryKey: ['/api/projects'],
    select: (data: Project[]) => data
  });

  const currentProject = projects?.[0]; // Use first project for demo

  // Update project files mutation
  const updateProjectMutation = useMutation({
    mutationFn: async ({ projectId, files }: { projectId: number; files: any }) => {
      const response = await apiRequest('PATCH', `/api/projects/${projectId}`, { files });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
    }
  });

  // Load file content when project is available
  useEffect(() => {
    if (currentProject && selectedFile && currentProject.files[selectedFile]) {
      const fileContent = currentProject.files[selectedFile].content;
      setOpenTabs(prev => 
        prev.map(tab => 
          tab.path === selectedFile 
            ? { ...tab, content: fileContent }
            : tab
        )
      );
    }
  }, [currentProject, selectedFile]);

  const handleFileSelect = (path: string) => {
    setSelectedFile(path);
    
    // Check if tab is already open
    const existingTab = openTabs.find(tab => tab.path === path);
    if (existingTab) {
      setActiveTab(existingTab.id);
      return;
    }

    // Create new tab
    if (currentProject?.files[path]) {
      const fileName = path.split('/').pop() || path;
      const newTab: OpenTab = {
        id: `tab-${Date.now()}`,
        name: fileName,
        path,
        content: currentProject.files[path].content,
        language: getLanguageFromPath(path)
      };
      
      setOpenTabs(prev => [...prev, newTab]);
      setActiveTab(newTab.id);
    }
  };

  const handleTabClose = (tabId: string) => {
    setOpenTabs(prev => prev.filter(tab => tab.id !== tabId));
    if (activeTab === tabId) {
      const remainingTabs = openTabs.filter(tab => tab.id !== tabId);
      setActiveTab(remainingTabs.length > 0 ? remainingTabs[0].id : null);
    }
  };

  const handleCodeChange = (newCode: string) => {
    if (!activeTab || !currentProject) return;

    const currentTab = openTabs.find(tab => tab.id === activeTab);
    if (!currentTab) return;

    // Update tab content and mark as dirty
    setOpenTabs(prev =>
      prev.map(tab =>
        tab.id === activeTab
          ? { ...tab, content: newCode, isDirty: true }
          : tab
      )
    );

    // Debounced save to backend
    const timeoutId = setTimeout(() => {
      const updatedFiles = {
        ...currentProject.files,
        [currentTab.path]: {
          ...currentProject.files[currentTab.path],
          content: newCode
        }
      };

      updateProjectMutation.mutate({
        projectId: currentProject.id,
        files: updatedFiles
      });

      // Mark tab as saved
      setOpenTabs(prev =>
        prev.map(tab =>
          tab.id === activeTab
            ? { ...tab, isDirty: false }
            : tab
        )
      );
    }, 1000);

    return () => clearTimeout(timeoutId);
  };

  const handleCreateFile = (path: string) => {
    const fileName = prompt('Enter file name:');
    if (!fileName || !currentProject) return;

    const fullPath = path ? `${path}/${fileName}` : fileName;
    const updatedFiles = {
      ...currentProject.files,
      [fullPath]: {
        content: '',
        type: getLanguageFromPath(fullPath)
      }
    };

    updateProjectMutation.mutate({
      projectId: currentProject.id,
      files: updatedFiles
    });
  };

  const handleCreateFolder = (path: string) => {
    const folderName = prompt('Enter folder name:');
    if (!folderName) return;
    // Folder creation logic would go here
    console.log('Creating folder:', folderName);
  };

  const handleCodeGenerated = (code: string, fileName: string) => {
    if (!currentProject) return;

    const updatedFiles = {
      ...currentProject.files,
      [fileName]: {
        content: code,
        type: getLanguageFromPath(fileName)
      }
    };

    updateProjectMutation.mutate({
      projectId: currentProject.id,
      files: updatedFiles
    });

    // Open the new file in a tab
    handleFileSelect(fileName);
  };

  const getLanguageFromPath = (path: string): string => {
    const ext = path.split('.').pop()?.toLowerCase();
    const langMap: Record<string, string> = {
      'js': 'javascript',
      'jsx': 'javascript',
      'ts': 'typescript',
      'tsx': 'typescript',
      'py': 'python',
      'html': 'html',
      'css': 'css',
      'json': 'json',
      'md': 'markdown'
    };
    return langMap[ext || ''] || 'plaintext';
  };

  const currentTabContent = openTabs.find(tab => tab.id === activeTab);

  return (
    <div className="h-screen flex flex-col bg-[#171717] text-white">
      {/* Top Navigation */}
      <Navigation
        projectName={currentProject?.name || 'Loading...'}
        onDeploy={() => console.log('Deploy clicked')}
        onSettings={() => console.log('Settings clicked')}
      />

      {/* Main IDE Layout */}
      <div className="flex flex-1 overflow-hidden">
        {/* File Explorer */}
        <FileExplorer
          project={currentProject || null}
          selectedFile={selectedFile}
          onFileSelect={handleFileSelect}
          onCreateFile={handleCreateFile}
          onCreateFolder={handleCreateFolder}
        />

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col">
          {/* Editor Tabs */}
          <EditorTabs
            tabs={openTabs}
            activeTab={activeTab}
            onTabSelect={setActiveTab}
            onTabClose={handleTabClose}
          />

          {/* Editor and Right Panel Container */}
          <div className="flex-1 flex overflow-hidden">
            {/* Code Editor */}
            <div className="flex-1 flex flex-col bg-[#171717]">
              {/* Editor Header */}
              <div className="bg-[#1E1E1E] px-4 py-2 border-b border-[#3C3C3C] flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <span className="text-sm font-mono text-gray-300">
                    {currentTabContent?.path || 'No file selected'}
                  </span>
                  <div className="flex items-center space-x-2 text-xs text-gray-400">
                    <span>Lines: 127</span>
                    <span>Size: 3.2KB</span>
                    {currentTabContent && !currentTabContent.isDirty && (
                      <span className="text-green-400">✓ Saved</span>
                    )}
                    {currentTabContent?.isDirty && (
                      <span className="text-yellow-400">● Modified</span>
                    )}
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="text-xs bg-purple-600 hover:bg-purple-700 border-purple-600 text-white"
                  >
                    <Brain size={12} className="mr-1" />
                    AI Optimize
                  </Button>
                </div>
              </div>

              {/* Editor */}
              <div className="flex-1">
                {currentTabContent ? (
                  <SimpleEditor
                    value={currentTabContent.content}
                    language={currentTabContent.language}
                    onChange={handleCodeChange}
                    theme="dark"
                  />
                ) : (
                  <div className="h-full flex items-center justify-center text-gray-500">
                    <div className="text-center">
                      <Brain size={48} className="mx-auto mb-4 opacity-50" />
                      <p>Select a file to start editing</p>
                      <p className="text-sm">or ask AI to generate code for you</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* AI Chat Panel */}
            <AIChat
              project={currentProject || null}
              onCodeGenerated={handleCodeGenerated}
              onCreateFile={(path, content) => {
                if (!currentProject) return;
                const updatedFiles = {
                  ...currentProject.files,
                  [path]: { content, type: getLanguageFromPath(path) }
                };
                updateProjectMutation.mutate({
                  projectId: currentProject.id,
                  files: updatedFiles
                });
              }}
            />
          </div>

          {/* Bottom Terminal Panel */}
          <Terminal
            isVisible={isTerminalVisible}
            onToggle={() => setIsTerminalVisible(!isTerminalVisible)}
          />
        </div>
      </div>

      {/* Floating AI Assistant */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setShowAIFloat(!showAIFloat)}
          className="w-14 h-14 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 relative group"
        >
          <Brain size={24} className="text-white group-hover:scale-110 transition-transform" />
          <div className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full text-xs flex items-center justify-center text-white font-bold">
            3
          </div>
        </Button>
      </div>
    </div>
  );
}
