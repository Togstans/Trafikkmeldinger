export interface FileNode {
  name: string;
  type: 'file' | 'folder';
  content?: string;
  children?: FileNode[];
  path: string;
  language?: string;
}

export interface Project {
  id: number;
  name: string;
  description?: string;
  files: Record<string, { content: string; type: string }>;
  userId: number;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface OpenTab {
  id: string;
  name: string;
  path: string;
  content: string;
  language?: string;
  isDirty?: boolean;
}

export interface AIMessage {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: string;
  actions?: AIAction[];
}

export interface AIAction {
  type: 'apply_code' | 'view_code' | 'create_file';
  label: string;
  data?: any;
}

export interface CodeGenerationResult {
  code: string;
  fileName: string;
  explanation: string;
  dependencies: string[];
}

export interface CollaboratorInfo {
  id: string;
  name: string;
  avatar: string;
  isOnline: boolean;
}
