# Master AI IDE

## Overview

Master AI is a cutting-edge cloud IDE that revolutionizes software development through AI-first, prompt-based coding. Built as a powerful fusion of Replit, GitHub Copilot, ChatGPT Code Interpreter, and VS Code, it enables developers to build full applications simply by describing what they want in natural language.

The platform features a modern React-based IDE with integrated AI assistance, real-time code generation, intelligent debugging, and one-click deployment capabilities. Users can create everything from simple components to full-stack applications through conversational prompts.

## User Preferences

Preferred communication style: Simple, everyday language.
Feature priorities: AI-powered code generation, intuitive UI/UX, seamless workflow integration.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Code Editor**: Monaco Editor for syntax highlighting and code editing
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with JSON responses
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Session Management**: Express sessions with PostgreSQL storage

### Data Storage
- **Primary Database**: PostgreSQL (configured via Neon serverless)
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Storage Interface**: Abstracted storage layer with database implementation
- **Development Mode**: In-memory storage for rapid development
- **Production Mode**: Full PostgreSQL with connection pooling

## Key Components

### Database Schema
- **Users Table**: Basic user authentication (id, username, email, password)
- **Projects Table**: Project metadata with JSONB file storage (id, name, description, userId, files, timestamps)
- **AI Sessions Table**: Chat history and AI interactions (id, projectId, messages, createdAt)

### AI Integration
- **OpenAI Integration**: GPT-4o powered code generation and chat assistance
- **AI Services**: Code generation, optimization, debugging, and explanation features
- **Chat Interface**: Real-time AI assistance with conversation history and action buttons
- **Prompt-Based Development**: Natural language commands for building applications
- **Smart Suggestions**: Context-aware AI recommendations and improvements
- **Multi-Language Support**: JavaScript, TypeScript, React, Node.js, Python, and more

### IDE Features
- **File Explorer**: Hierarchical file tree with create/delete operations and Git integration
- **Monaco Editor**: VS Code-powered editor with syntax highlighting and custom themes
- **Terminal**: Multi-tab terminal with command history, output display, and live preview
- **Tab Management**: Multiple file editing with dirty state tracking and auto-save
- **AI Chat Panel**: Integrated AI assistant with code generation and debugging tools
- **Live Collaboration**: Real-time editing indicators and team member presence
- **Smart Code Actions**: AI-powered code optimization and refactoring suggestions

### UI/UX Design
- **Theme**: Dark mode IDE interface with VS Code-inspired styling
- **Responsive Design**: Mobile-friendly with collapsible panels
- **Component System**: Consistent design system using Radix UI and shadcn/ui
- **Accessibility**: ARIA compliant components with keyboard navigation

## Data Flow

### Project Management Flow
1. **Project Loading**: Fetch project data from `/api/projects` endpoint
2. **File Operations**: CRUD operations on project files stored as JSONB
3. **Real-time Updates**: Optimistic updates with React Query invalidation
4. **Persistence**: Auto-save functionality with debounced API calls

### AI Interaction Flow
1. **User Input**: Code generation requests or chat messages
2. **Context Building**: Include project context and conversation history
3. **OpenAI API**: Process requests through GPT models
4. **Response Handling**: Parse and display AI responses with action buttons
5. **Code Integration**: Apply generated code directly to editor

### Authentication Flow
- **Demo Mode**: Currently uses a hardcoded demo user (ID: 1)
- **Session Management**: Express sessions with PostgreSQL storage
- **Future Enhancement**: Planned support for full authentication system

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **drizzle-orm**: Type-safe ORM with PostgreSQL dialect
- **openai**: Official OpenAI API client
- **monaco-editor**: Code editor component
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI primitives

### Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type safety and development experience
- **Tailwind CSS**: Utility-first CSS framework
- **ESBuild**: Fast JavaScript bundler for production builds

### Third-party Integrations
- **OpenAI API**: GPT models for code generation and chat
- **Neon Database**: Serverless PostgreSQL hosting
- **Replit Platform**: Development environment integration

## Recent Changes

### Latest Updates (July 15, 2025)
✓ Built comprehensive AI-powered cloud IDE with prompt-based development
✓ Implemented Monaco Editor with custom Master AI dark theme
✓ Created intelligent file explorer with Git status integration
✓ Added multi-panel terminal with live preview capabilities
✓ Integrated OpenAI GPT-4o for code generation and chat assistance
✓ Built real-time collaboration features with user presence indicators
✓ Implemented smart tab management with dirty state tracking
✓ Added AI suggestion system with actionable code improvements
✓ Created professional navigation with deployment and settings
✓ Established secure API architecture with environment variable support
✓ Created chat-first interface matching user's design vision
✓ Built prompt-based project creation with natural language input
✓ Added quick-start templates for common project types
✓ Implemented gradient UI design with glassmorphism effects
✓ Integrated PostgreSQL database with Drizzle ORM
✓ Added database initialization and migration system
✓ Implemented dual storage strategy (memory for dev, database for production)
✓ Created comprehensive admin dashboard with user management
✓ Added subscription management and analytics tracking
✓ Implemented role-based access control with admin privileges
✓ Built clickable interface with full CRUD operations

### Next Steps
→ OpenAI API key integration for live AI features
→ Enhanced deployment pipeline with one-click publishing
→ Real-time multiplayer editing implementation
→ Advanced code templates and project scaffolding
→ Performance optimization and bundle size reduction

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with hot module replacement on port 5000
- **Database**: In-memory storage for rapid prototyping (PostgreSQL ready)
- **API Integration**: RESTful backend with OpenAI GPT-4o integration
- **Real-time Features**: WebSocket support for live collaboration

### Production Build
- **Frontend**: Optimized React build with Monaco Editor integration
- **Backend**: Express server with AI service endpoints
- **Database**: PostgreSQL with Drizzle ORM migrations
- **Environment**: Secure API key management and environment configuration

### Build Process
1. **Dependency Management**: Monaco Editor and OpenAI client installed
2. **TypeScript Compilation**: Full-stack type safety with shared schemas
3. **Asset Optimization**: Vite handles code splitting and asset bundling
4. **Database Setup**: Drizzle Kit for schema management and migrations

### Configuration Management
- **Environment Variables**: OPENAI_API_KEY for AI features
- **Build Scripts**: Development and production workflows configured
- **Path Aliases**: Clean import structure with TypeScript path mapping
- **Security**: API key protection and secure service endpoints