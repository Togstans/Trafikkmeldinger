import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { codeGenerationSchema } from "@shared/schema";
import OpenAI from "openai";

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "sk-test-key"
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Admin Routes
  app.get("/api/admin/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  app.get("/api/admin/projects", async (req, res) => {
    try {
      const projects = await storage.getAllProjects();
      res.json(projects);
    } catch (error) {
      console.error("Error fetching projects:", error);
      res.status(500).json({ error: "Failed to fetch projects" });
    }
  });

  app.get("/api/admin/analytics", async (req, res) => {
    try {
      const analytics = await storage.getAnalytics();
      res.json(analytics);
    } catch (error) {
      console.error("Error fetching analytics:", error);
      res.status(500).json({ error: "Failed to fetch analytics" });
    }
  });

  app.get("/api/admin/settings", async (req, res) => {
    try {
      const settings = await storage.getSystemSettings();
      res.json(settings);
    } catch (error) {
      console.error("Error fetching settings:", error);
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  app.put("/api/admin/users/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const updates = req.body;
      const user = await storage.updateUser(parseInt(id), updates);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ error: "Failed to update user" });
    }
  });

  app.delete("/api/admin/users/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const success = await storage.deleteUser(parseInt(id));
      if (!success) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json({ message: "User deleted successfully" });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ error: "Failed to delete user" });
    }
  });

  app.put("/api/admin/settings/:key", async (req, res) => {
    try {
      const { key } = req.params;
      const { value } = req.body;
      const setting = await storage.updateSystemSetting(key, value);
      res.json(setting);
    } catch (error) {
      console.error("Error updating setting:", error);
      res.status(500).json({ error: "Failed to update setting" });
    }
  });

  // Initialize database with demo data if empty
  app.get("/api/init-db", async (req, res) => {
    try {
      // Check if demo user exists
      const demoUser = await storage.getUserByUsername("demo");
      
      if (!demoUser) {
        // Create demo user
        const user = await storage.createUser({
          username: "demo",
          email: "demo@masterai.com",
          password: "demo123"
        });

        // Create demo project
        await storage.createProject({
          name: "my-social-app",
          description: "AI Generated Social Media App",
          userId: user.id,
          files: {
            "src/App.jsx": {
              content: `import React from 'react';\nimport Feed from './components/Feed';\n\nfunction App() {\n  return (\n    <div className="App">\n      <Feed />\n    </div>\n  );\n}\n\nexport default App;`,
              type: "javascript"
            },
            "src/components/Feed.jsx": {
              content: `import React, { useState, useEffect } from 'react';\nimport UserCard from './UserCard';\n\n// AI Generated Component - Social Media Feed\nconst Feed = () => {\n  const [posts, setPosts] = useState([]);\n  const [loading, setLoading] = useState(true);\n\n  useEffect(() => {\n    // TODO: Implement API call to fetch posts\n    fetchPosts();\n  }, []);\n\n  return (\n    <div className="feed-container max-w-2xl mx-auto p-4">\n      {loading ? (\n        <div>Loading posts...</div>\n      ) : (\n        posts.map(post => (\n          <UserCard key={post.id} post={post} />\n        ))\n      )}\n    </div>\n  );\n};\n\nexport default Feed;`,
              type: "javascript"
            },
            "package.json": {
              content: `{\n  "name": "my-social-app",\n  "version": "1.0.0",\n  "dependencies": {\n    "react": "^18.0.0",\n    "react-dom": "^18.0.0"\n  }\n}`,
              type: "json"
            }
          }
        });
      }
      
      res.json({ message: "Database initialized successfully" });
    } catch (error) {
      console.error("Database initialization error:", error);
      res.status(500).json({ error: "Failed to initialize database" });
    }
  });
  
  // Get all projects for demo user
  app.get("/api/projects", async (req, res) => {
    try {
      const projects = await storage.getProjectsByUserId(1); // Demo user ID
      res.json(projects);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch projects" });
    }
  });

  // Get project by ID
  app.get("/api/projects/:id", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const project = await storage.getProject(projectId);
      
      if (!project) {
        return res.status(404).json({ error: "Project not found" });
      }
      
      res.json(project);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch project" });
    }
  });

  // Update project files
  app.patch("/api/projects/:id", async (req, res) => {
    try {
      const projectId = parseInt(req.params.id);
      const { files } = req.body;
      
      const updatedProject = await storage.updateProject(projectId, { files });
      
      if (!updatedProject) {
        return res.status(404).json({ error: "Project not found" });
      }
      
      res.json(updatedProject);
    } catch (error) {
      res.status(500).json({ error: "Failed to update project" });
    }
  });

  // AI code generation endpoint
  app.post("/api/ai/generate", async (req, res) => {
    try {
      const validatedData = codeGenerationSchema.parse(req.body);
      const { prompt, fileType = "react", projectContext } = validatedData;

      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      const completion = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `You are Master AI, an expert code generation assistant. Generate high-quality, production-ready code based on user prompts. 

Current context:
- File type: ${fileType}
- Project context: ${projectContext || "General web application"}

Rules:
1. Generate complete, functional code
2. Include proper error handling
3. Use modern best practices
4. Add helpful comments
5. Ensure code is ready to run
6. For React components, use functional components with hooks
7. For Node.js, use modern ES6+ syntax
8. Include necessary imports

Respond with JSON in this format:
{
  "code": "generated code here",
  "fileName": "suggested filename",
  "explanation": "brief explanation of what was generated",
  "dependencies": ["array", "of", "required", "packages"]
}`
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7,
        max_tokens: 2000
      });

      const result = JSON.parse(completion.choices[0].message.content || "{}");
      res.json(result);
    } catch (error) {
      console.error("AI generation error:", error);
      res.status(500).json({ 
        error: "Failed to generate code", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // AI chat endpoint
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const { message, projectId, conversationHistory = [] } = req.body;

      if (!message) {
        return res.status(400).json({ error: "Message is required" });
      }

      // Get project context if projectId is provided
      let projectContext = "";
      if (projectId) {
        const project = await storage.getProject(projectId);
        if (project && project.files) {
          projectContext = `Current project: ${project.name}\nFiles: ${Object.keys(project.files as Record<string, any>).join(", ")}`;
        }
      }

      const messages = [
        {
          role: "system" as const,
          content: `You are Master AI, a helpful coding assistant integrated into a cloud IDE. Help users with:
- Code generation and optimization
- Debugging and error fixing
- Architecture suggestions
- Best practices
- Deployment guidance

${projectContext ? `\nProject Context:\n${projectContext}` : ""}

Keep responses concise and actionable. Always provide specific, implementable advice.`
        },
        ...conversationHistory,
        {
          role: "user" as const,
          content: message
        }
      ];

      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      const completion = await openai.chat.completions.create({
        model: "gpt-4o",
        messages,
        temperature: 0.7,
        max_tokens: 1000
      });

      const response = completion.choices[0].message.content;
      res.json({ response, timestamp: new Date().toISOString() });
    } catch (error) {
      console.error("AI chat error:", error);
      res.status(500).json({ 
        error: "Failed to process chat message",
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Create new project
  app.post("/api/projects", async (req, res) => {
    try {
      const { name, description, template = "react" } = req.body;
      
      // Default templates
      const templates = {
        react: {
          "src/App.jsx": {
            content: `import React from 'react';\n\nfunction App() {\n  return (\n    <div className="App">\n      <h1>Hello World</h1>\n    </div>\n  );\n}\n\nexport default App;`,
            type: "javascript"
          },
          "package.json": {
            content: `{\n  "name": "${name}",\n  "version": "1.0.0",\n  "dependencies": {\n    "react": "^18.0.0",\n    "react-dom": "^18.0.0"\n  }\n}`,
            type: "json"
          }
        },
        node: {
          "index.js": {
            content: `const express = require('express');\nconst app = express();\nconst PORT = process.env.PORT || 3000;\n\napp.get('/', (req, res) => {\n  res.json({ message: 'Hello World!' });\n});\n\napp.listen(PORT, () => {\n  console.log(\`Server running on port \${PORT}\`);\n});`,
            type: "javascript"
          },
          "package.json": {
            content: `{\n  "name": "${name}",\n  "version": "1.0.0",\n  "dependencies": {\n    "express": "^4.18.0"\n  }\n}`,
            type: "json"
          }
        }
      };

      const project = await storage.createProject({
        name,
        description,
        userId: 1, // Demo user
        files: templates[template as keyof typeof templates] || templates.react
      });

      res.json(project);
    } catch (error) {
      res.status(500).json({ error: "Failed to create project" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
