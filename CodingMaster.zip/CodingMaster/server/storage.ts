import { 
  users, 
  projects, 
  aiSessions, 
  subscriptions, 
  analytics, 
  systemSettings,
  type User, 
  type InsertUser, 
  type Project, 
  type InsertProject, 
  type AISession, 
  type InsertAISession,
  type Subscription,
  type InsertSubscription,
  type Analytics,
  type InsertAnalytics,
  type SystemSettings,
  type InsertSystemSettings
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getAllUsers(): Promise<User[]>;

  // Project operations
  getProject(id: number): Promise<Project | undefined>;
  getProjectsByUserId(userId: number): Promise<Project[]>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, updates: Partial<Project>): Promise<Project | undefined>;
  deleteProject(id: number): Promise<boolean>;
  getAllProjects(): Promise<Project[]>;

  // AI Session operations
  getAISession(id: number): Promise<AISession | undefined>;
  getAISessionsByProjectId(projectId: number): Promise<AISession[]>;
  createAISession(session: InsertAISession): Promise<AISession>;
  updateAISession(id: number, updates: Partial<AISession>): Promise<AISession | undefined>;

  // Subscription operations
  getSubscription(userId: number): Promise<Subscription | undefined>;
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  updateSubscription(id: number, updates: Partial<Subscription>): Promise<Subscription | undefined>;

  // Analytics operations
  createAnalytics(analytics: InsertAnalytics): Promise<Analytics>;
  getAnalytics(userId?: number, eventType?: string): Promise<Analytics[]>;

  // System Settings operations
  getSystemSettings(): Promise<SystemSettings[]>;
  updateSystemSetting(key: string, value: string): Promise<SystemSettings | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private projects: Map<number, Project>;
  private aiSessions: Map<number, AISession>;
  private currentUserId: number;
  private currentProjectId: number;
  private currentAISessionId: number;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.aiSessions = new Map();
    this.currentUserId = 1;
    this.currentProjectId = 1;
    this.currentAISessionId = 1;

    // Initialize with admin user
    this.initializeAdminUser();
  }

  private async initializeAdminUser() {
    const admin = await this.createUser({
      username: "admin",
      email: "admin@masterai.com",
      password: "admin123",
      role: "admin",
      subscriptionPlan: "enterprise",
      firstName: "Admin",
      lastName: "User",
      isActive: true
    });

    // Create demo user
    const demo = await this.createUser({
      username: "demo",
      email: "demo@masterai.com",
      password: "demo123"
    });

    // Create demo project
    await this.createProject({
      name: "my-social-app",
      description: "AI Generated Social Media App",
      userId: demo.id,
      files: {
        "src/App.jsx": {
          content: `import React from 'react';
import Feed from './components/Feed';

function App() {
  return (
    <div className="App">
      <Feed />
    </div>
  );
}

export default App;`,
          type: "javascript"
        }
      }
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      role: insertUser.role || "user",
      subscriptionPlan: insertUser.subscriptionPlan || "free",
      avatar: insertUser.avatar || null,
      firstName: insertUser.firstName || null,
      lastName: insertUser.lastName || null,
      isActive: insertUser.isActive !== undefined ? insertUser.isActive : true,
      lastLogin: null,
      apiUsage: 0,
      maxApiUsage: 1000,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates, updatedAt: new Date() };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async getProject(id: number): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async getProjectsByUserId(userId: number): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(project => project.userId === userId);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = this.currentProjectId++;
    const now = new Date();
    const project: Project = { 
      ...insertProject, 
      id, 
      description: insertProject.description || null,
      files: insertProject.files || {},
      createdAt: now,
      updatedAt: now
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id: number, updates: Partial<Project>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;
    
    const updatedProject = { 
      ...project, 
      ...updates, 
      updatedAt: new Date() 
    };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  async deleteProject(id: number): Promise<boolean> {
    return this.projects.delete(id);
  }

  async getAllProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async getAISession(id: number): Promise<AISession | undefined> {
    return this.aiSessions.get(id);
  }

  async getAISessionsByProjectId(projectId: number): Promise<AISession[]> {
    return Array.from(this.aiSessions.values()).filter(session => session.projectId === projectId);
  }

  async createAISession(insertSession: InsertAISession): Promise<AISession> {
    const id = this.currentAISessionId++;
    const session: AISession = { 
      ...insertSession, 
      id, 
      messages: insertSession.messages || [],
      createdAt: new Date()
    };
    this.aiSessions.set(id, session);
    return session;
  }

  async updateAISession(id: number, updates: Partial<AISession>): Promise<AISession | undefined> {
    const session = this.aiSessions.get(id);
    if (!session) return undefined;
    
    const updatedSession = { ...session, ...updates };
    this.aiSessions.set(id, updatedSession);
    return updatedSession;
  }

  async getSubscription(userId: number): Promise<Subscription | undefined> {
    return {
      id: 1,
      userId,
      plan: "enterprise",
      status: "active",
      currentPeriodStart: new Date(),
      currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      cancelAtPeriodEnd: false,
      createdAt: new Date(),
      updatedAt: new Date()
    };
  }

  async createSubscription(subscription: InsertSubscription): Promise<Subscription> {
    const newSubscription: Subscription = {
      ...subscription,
      id: 1,
      status: subscription.status || "active",
      cancelAtPeriodEnd: subscription.cancelAtPeriodEnd || false,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    return newSubscription;
  }

  async updateSubscription(id: number, updates: Partial<Subscription>): Promise<Subscription | undefined> {
    return {
      id,
      userId: 1,
      plan: "enterprise",
      status: "active",
      currentPeriodStart: new Date(),
      currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      cancelAtPeriodEnd: false,
      createdAt: new Date(),
      updatedAt: new Date(),
      ...updates
    };
  }

  async createAnalytics(analytics: InsertAnalytics): Promise<Analytics> {
    return {
      ...analytics,
      id: 1,
      eventData: analytics.eventData || {},
      createdAt: new Date()
    };
  }

  async getAnalytics(userId?: number, eventType?: string): Promise<Analytics[]> {
    return [
      {
        id: 1,
        userId: userId || 1,
        eventType: eventType || "login",
        eventData: {},
        createdAt: new Date()
      }
    ];
  }

  async getSystemSettings(): Promise<SystemSettings[]> {
    return [
      {
        id: 1,
        key: "maintenance_mode",
        value: "false",
        description: "Enable maintenance mode",
        updatedAt: new Date()
      },
      {
        id: 2,
        key: "max_projects_per_user",
        value: "10",
        description: "Maximum projects per user",
        updatedAt: new Date()
      }
    ];
  }

  async updateSystemSetting(key: string, value: string): Promise<SystemSettings | undefined> {
    return {
      id: 1,
      key,
      value,
      description: "System setting",
      updatedAt: new Date()
    };
  }
}

// Database Storage Implementation
export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id));
    return result.rowCount !== null && result.rowCount > 0;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project || undefined;
  }

  async getProjectsByUserId(userId: number): Promise<Project[]> {
    return await db.select().from(projects).where(eq(projects.userId, userId));
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const [project] = await db
      .insert(projects)
      .values(insertProject)
      .returning();
    return project;
  }

  async updateProject(id: number, updates: Partial<Project>): Promise<Project | undefined> {
    const [project] = await db
      .update(projects)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(projects.id, id))
      .returning();
    return project || undefined;
  }

  async deleteProject(id: number): Promise<boolean> {
    const result = await db.delete(projects).where(eq(projects.id, id));
    return result.rowCount !== null && result.rowCount > 0;
  }

  async getAllProjects(): Promise<Project[]> {
    return await db.select().from(projects);
  }

  async getAISession(id: number): Promise<AISession | undefined> {
    const [session] = await db.select().from(aiSessions).where(eq(aiSessions.id, id));
    return session || undefined;
  }

  async getAISessionsByProjectId(projectId: number): Promise<AISession[]> {
    return await db.select().from(aiSessions).where(eq(aiSessions.projectId, projectId));
  }

  async createAISession(insertSession: InsertAISession): Promise<AISession> {
    const [session] = await db
      .insert(aiSessions)
      .values(insertSession)
      .returning();
    return session;
  }

  async updateAISession(id: number, updates: Partial<AISession>): Promise<AISession | undefined> {
    const [session] = await db
      .update(aiSessions)
      .set(updates)
      .where(eq(aiSessions.id, id))
      .returning();
    return session || undefined;
  }

  async getSubscription(userId: number): Promise<Subscription | undefined> {
    const [subscription] = await db.select().from(subscriptions).where(eq(subscriptions.userId, userId));
    return subscription || undefined;
  }

  async createSubscription(insertSubscription: InsertSubscription): Promise<Subscription> {
    const [subscription] = await db
      .insert(subscriptions)
      .values(insertSubscription)
      .returning();
    return subscription;
  }

  async updateSubscription(id: number, updates: Partial<Subscription>): Promise<Subscription | undefined> {
    const [subscription] = await db
      .update(subscriptions)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(subscriptions.id, id))
      .returning();
    return subscription || undefined;
  }

  async createAnalytics(insertAnalytics: InsertAnalytics): Promise<Analytics> {
    const [analyticsRecord] = await db
      .insert(analytics)
      .values(insertAnalytics)
      .returning();
    return analyticsRecord;
  }

  async getAnalytics(userId?: number, eventType?: string): Promise<Analytics[]> {
    if (userId) {
      return await db.select().from(analytics).where(eq(analytics.userId, userId));
    }
    
    return await db.select().from(analytics);
  }

  async getSystemSettings(): Promise<SystemSettings[]> {
    return await db.select().from(systemSettings);
  }

  async updateSystemSetting(key: string, value: string): Promise<SystemSettings | undefined> {
    const [setting] = await db
      .update(systemSettings)
      .set({ value, updatedAt: new Date() })
      .where(eq(systemSettings.key, key))
      .returning();
    return setting || undefined;
  }
}

// Use database storage in production, memory storage for development
export const storage = process.env.NODE_ENV === 'production' 
  ? new DatabaseStorage() 
  : new MemStorage();